
class Contractor extends Employee {

    public Contractor(int id, String firstName, String lastName) {
        super(id, firstName, lastName);
    }
    
    @Override
    public double getMonthlyPay() {
        return 0.0;
    }
        
}
