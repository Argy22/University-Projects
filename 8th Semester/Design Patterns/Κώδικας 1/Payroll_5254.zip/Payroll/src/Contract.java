class Contract{

    private final int id;
    private final String month;
    private final double amount;

    public Contract(int id, String month, double amount) {
        this.id = id;
        this.month = month;
        this.amount = amount;
    }

    public int getId() {
        return id;
    }

    public String getMonth() {
        return month;
    }

    public double getAmount() {
        return amount;
    }

}