class HighPaidEmployee extends Employee {

    private static final double monthlyPayHP = 2000.0;

    public HighPaidEmployee(int id, String firstName, String lastName) {
        super(id, firstName, lastName);
    }

    @Override
    public double getMonthlyPay() {
        return monthlyPayHP;
    }
}