class LowPaidEmployee extends Employee {

    private static final double monthlyPayLP = 1000.0;

    public LowPaidEmployee(int id, String firstName, String lastName) {
        super(id, firstName, lastName);
    }

    @Override
    public double getMonthlyPay() {
        return monthlyPayLP;
    }
}