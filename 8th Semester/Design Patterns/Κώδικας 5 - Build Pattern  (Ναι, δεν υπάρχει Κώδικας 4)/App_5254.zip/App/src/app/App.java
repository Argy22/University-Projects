package app;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Ingredient {
    String name;
    int calories;

    public Ingredient(String name, int calories) {
        this.name = name;
        this.calories = calories;
    }

    public int getCalories() {
        return this.calories;
    }

    public String getName() {
        return this.name;
    }
}

class Piato {
    List<Ingredient> ingredients;

    public Piato() {
        this.ingredients = new ArrayList<>();
    }

    public void addIngredient(Ingredient ingredient) {
        this.ingredients.add(ingredient);
    }

    public int getCalories() {
        int totalCalories = 0;
        for (Ingredient ingredient : this.ingredients) {
            totalCalories += ingredient.getCalories();
        }
        return totalCalories;
    }

    public String getDescription() {
        StringBuilder sb = new StringBuilder();
        for (Ingredient ingredient : this.ingredients) {
            sb.append(ingredient.getName() + ", ");
        }
        return sb.toString();
    }
}

class Builder {
    Piato piato;

    public Builder() {
        this.piato = new Piato();
    }

    
    public void add(String... ingredients) {
    for (String ingredient : ingredients) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Thermidologio.txt"));
            String line = reader.readLine();
            while (line != null) {
                // Διαχωρίστε την γραμμή σε όνομα υλικού και θερμίδες
                String[] parts = line.split(" ");
                if (parts.length == 2) {
                    String ingredientName = parts[0].trim();
                    int calories = Integer.parseInt(parts[1].trim());
                    if (ingredient.equals(ingredientName)) {
                        this.piato.addIngredient(new Ingredient(ingredient, calories));
                        break;
                    }
                }
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


    public Piato getProduct() {
        return this.piato;
    }
}

class FactoryPiato {
    public static Piato getPiato(String type) {
        Builder builder = new Builder();
        switch (type) {
            case "xwriatikh":
                builder.add("Tomato", "Feta-cheese", "Olive-oil", "Bread");
                break;
            case "mprizola-patates":
                builder.add("Olive-oil", "Pork-chop", "Fries");
                break;
            case "kotopoulo-ryzi":
                builder.add("Roast-chicken", "Boiled-rice");
                break;
        }
        return builder.getProduct();
    }
}

public class App {
    public static void main(String[] args) {
        Builder b = new Builder();
        b.add("Tomato");
        b.add("Feta-cheese", "Olive-oil");
        Piato p1 = b.getProduct();
        System.out.println(p1.getDescription() + " " + p1.getCalories());

        Piato p2 = FactoryPiato.getPiato("xwriatikh");
        System.out.println(p2.getDescription() + " " + p2.getCalories());  
    }
}
