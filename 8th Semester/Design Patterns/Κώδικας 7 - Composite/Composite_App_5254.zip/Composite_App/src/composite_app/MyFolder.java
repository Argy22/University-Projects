
package composite_app;

import java.util.ArrayList;
import java.util.List;


public class MyFolder implements FInfo {
  private String name;
  private List<FInfo> children;

  public MyFolder(String name) {
    this.name = name;
    this.children = new ArrayList<>();
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public int getSize() {
    int totalSize = 0;
    for (FInfo child : children) {
      totalSize += child.getSize();
    }
    return totalSize;
  }

  public void add(FInfo finfo) {
    children.add(finfo);
  }

 public void remove(FInfo fInfo) {
        children.remove(fInfo);
    }

    public List<FInfo> getChildren() {
        return children;
    }
}