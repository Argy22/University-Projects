package composite_app;

public class MyFile implements FInfo {
  private String name;
  private int size;

  public MyFile(String name, int size) {
    this.name = name;
    this.size = size;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public int getSize() {
    return size;
  }
}