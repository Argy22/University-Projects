package composite_app;

public class App {
    public static void main(String[] args) {
        // Create files
        MyFile file1 = new MyFile("File1.txt", 100);
        MyFile file2 = new MyFile("File2.txt", 200);
        MyFile file3 = new MyFile("File3.txt", 300);

        // Create folders and add files
        MyFolder folder1 = new MyFolder("Folder1");
        folder1.add(file1);

        MyFolder folder2 = new MyFolder("Folder2");
        folder2.add(file2);
        folder2.add(file3);

        // Create root folder and add folders
        MyFolder root = new MyFolder("Root");
        root.add(folder1);
        root.add(folder2);

        // Print the structure and sizes
        System.out.println(root.getName() + " Size: " + root.getSize() + "\n");
        for (FInfo fInfo : root.getChildren()) {
            System.out.println("  " + fInfo.getName() + " Size: " + fInfo.getSize());
            if (fInfo instanceof MyFolder) {
                MyFolder folder = (MyFolder) fInfo;
                for (FInfo child : folder.getChildren()) {
                    System.out.println("    " + child.getName() + " Size: " + child.getSize());
                }
                System.out.println("\n");
            }
        }
    }
}
