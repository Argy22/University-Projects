package composite_app;

public interface FInfo {
   
   String getName();

   int getSize();
   
}