
import lib.EDevice;
import lib.PowerAdapter;
import lib.PowerSocket;
import lib.Shaver;
import lib.TV;

public class Adapter_App {
    public static void main(String[] args) {
        
        EDevice tv=new TV("TV");
        EDevice shaver=new Shaver("Shaver");
        PowerSocket pS=new PowerSocket(1);
        
        //Προσπάθεια άμεσης σύνδεσης
        System.out.println("Direct Connection Attempt...\n");
        pS.supply(tv);
        pS.supply(shaver);
        
        //Διαχωριστικό
        System.out.println("\n-------------------------------------------\n");
        
        //Προσπάθεια σύνδεσης μέσω του adapter
        System.out.println("Connection Attempt via Adapter ...\n");
        PowerAdapter pATv=new PowerAdapter(pS.getId(),tv);
        PowerAdapter pAShaver=new PowerAdapter(pS.getId(),shaver);
        pATv.supply(tv);
        pAShaver.supply(shaver);
        
    }
    
}