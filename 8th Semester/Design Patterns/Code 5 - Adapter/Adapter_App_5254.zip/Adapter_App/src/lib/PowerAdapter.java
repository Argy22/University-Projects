package lib;

public class PowerAdapter extends PowerSocket {

    private EDevice device;

    public PowerAdapter(int id, EDevice device) {
        super(id);
        this.device = device;
    }

    @Override
    public void supply(EDevice eDev) {
        if (eDev.getVoltage() != super.getVoltage()) {
            System.out.println("Adapting voltage from " + super.getVoltage() + "V to " + eDev.getVoltage() + "V for device " + eDev.getDescription() + ".\n");
        }
        eDev.receive(this);
    }

    @Override
    public int getVoltage() {
        return device.getVoltage();
    }
}