public class Manager extends Employee {
    
   private static final double monthlyPayMN = 3000.0;

    public Manager (int id, String firstName, String lastName) {
        super(id, firstName, lastName);
    }


    @Override
    public double getMonthlyPay() {
        return monthlyPayMN;
    } 
}
