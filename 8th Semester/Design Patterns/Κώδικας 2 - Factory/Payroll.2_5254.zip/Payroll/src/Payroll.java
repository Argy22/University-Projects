import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Payroll {

    private static final String contracts = "contracts.txt";
    private static final String bonus = "bonus.txt";

    public static void main(String[] args) {

        List<Employee> employees = new ArrayList<>();

        Employee Jim = EmployeeFactory.create("low paid employee", "1", "Jim Black");
        employees.add(Jim);

        Employee Mary = EmployeeFactory.create("high paid employee", "2", "Mary Green");
        employees.add(Mary);

        Employee Nick = EmployeeFactory.create("contractor", "5", "Nick Yellow");
        employees.add(Nick);

        Employee Kelly = EmployeeFactory.create("contractor", "7", "Kelly Red");
        employees.add(Kelly);

        Employee John = EmployeeFactory.create("manager", "12", "John Blue");
        employees.add(John);

        Employee Jason = EmployeeFactory.create("manager", "13", "Jason Purple");
        employees.add(Jason);

        Employee James = EmployeeFactory.create("manager", "14", "James Brown");
        employees.add(James);

        String[] months = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST",
            "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"};

        List<Contract> contracts = readContracts("contacts.txt");
        List<ManagerBonus> bonus = readBonus("bonus.txt");

        for (Employee employee : employees) {

            double totalSalary = 0;
            double totalPay = 0;

            if (employee instanceof Contractor) {
                Contractor contractor = (Contractor) employee;
                for (String month : months) {
                    switch (month) {
                        case "JUNE":
                        case "JULY":
                        case "AUGUST":
                            for (Contract contract : contracts) {
                                if (contract.getMonth().equals(month) && contract.getId() == contractor.getId()) {
                                    totalPay += contract.getAmount();
                                    break;
                                }
                            }
                            break;
                    }
                }

                System.out.printf("%s: %.1f\n", "(" + employee.getFirstName() + ")" + " " + employee.getLastName(), totalSalary);
                
            } else if (employee instanceof LowPaidEmployee) {
                for (String month : months) {
                    switch (month) {
                        case "JUNE":
                        case "JULY":
                        case "AUGUST":
                            totalSalary += employee.getMonthlyPay();
                    }
                }

                System.out.printf("%s: %.1f\n", "(" + employee.getFirstName() + ")" + " " + employee.getLastName(), totalSalary);

            } else if (employee instanceof HighPaidEmployee) {
                for (String month : months) {
                    switch (month) {
                        case "JUNE":
                        case "JULY":
                        case "AUGUST":
                            totalSalary += employee.getMonthlyPay();
                    }
                }

                System.out.printf("%s: %.1f\n", "(" + employee.getFirstName() + ")" + " " + employee.getLastName(), totalSalary);

            } else if (employee instanceof Manager) {
                for (String month : months) {
                    switch (month) {
                        case "JUNE":
                        case "JULY":
                        case "AUGUST":

                            totalSalary += employee.getMonthlyPay();

                            for (ManagerBonus bonuss : bonus) {
                                if (bonuss.getId() == employee.getId()) {
                                    totalSalary += bonuss.getAmount();
                                }
                            }

                    }
                }

                System.out.printf("%s: %.1f\n", "(" + employee.getFirstName() + ")" + " " + employee.getLastName(), totalSalary);
            }
        }
    }

    private static List<Contract> readContracts(String filename) {
        List<Contract> contracts = new ArrayList<>();
        try (Scanner scanner = new Scanner(new File(filename))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(" ");
                int id = Integer.parseInt(parts[0]);
                String month = parts[1];
                double amount = Double.parseDouble(parts[2]);
                Contract contract = new Contract(id, month, amount);
                contracts.add(contract);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Error: " + filename + " not found.");
        }
        return contracts;
    }

    private static List<ManagerBonus> readBonus(String filename) {
        List<ManagerBonus> bonus = new ArrayList<>();
        try (Scanner scanner = new Scanner(new File(filename))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(" ");
                int id = Integer.parseInt(parts[0]);
                double amount = Double.parseDouble(parts[1]);
                ManagerBonus bonuss = new ManagerBonus(id, amount);
                bonus.add(bonuss);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Error: " + filename + " not found.");
        }
        return bonus;
    }
}
