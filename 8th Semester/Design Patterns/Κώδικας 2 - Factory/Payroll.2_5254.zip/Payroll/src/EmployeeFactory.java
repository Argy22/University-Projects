public class EmployeeFactory {
    
    private static LowPaidEmployee createLowPaidEmployee (String[] args){
        int id = Integer.parseInt(args[1]);
        return new LowPaidEmployee (id, args[0], args[2]);
    }
    
    private static HighPaidEmployee createHighPaidEmployee (String[] args){
        int id = Integer.parseInt(args[1]);
        return new HighPaidEmployee (id, args[0], args[2]);
    }
    
    private static Contractor createContractor (String[] args){
        int id = Integer.parseInt(args[1]);
        return new Contractor (id, args[0], args[2]);
    }
    
    private static Manager createManager (String[] args){
        int id = Integer.parseInt(args[1]);
        return new Manager (id, args[0], args[2]);
    }
    
    
    public static Employee create(String...args){
        switch (args[0].toLowerCase()){
            
            case "low paid employee":
                return createLowPaidEmployee(args);
                
            case "high paid employee":
                return createHighPaidEmployee(args);
                
            case "contractor":
                return createContractor(args);
                
            case "manager":
                return createManager(args);
                
            default:
                return null;
                
        }
        
    }

}
